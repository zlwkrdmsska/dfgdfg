# Traps And Trolls
Traps and Trolls plugin for spigot adds in a bunch of very useful traps as well as a few funny trolls

# Included traps
### Fire trap
sets the player who trigers it on fire

### poison trap
Poisons the player

### Glow trap
Makes the player glow for a full minute

### Launch trap
Launches the player into the air

### TNT trap
Summons a primed TNT 

### Lightning trap
Invokes the wrath of Zeus on the player

### Theif trap
Steals the item the player is holding and puts it in a chest

### Lava trap
Slowly lowers a player into lava

### Cage trap
Summons an obsidian cage around the player

# Included Trolls

### Fake Diamond Troll
Summons fake diamonds that cannot be picked up

### Herobrine Troll
A Jump-scare troll

### Fake OP Troll / Creative mode Troll
Tricks the player into thinking they are OP or have creative mode.
